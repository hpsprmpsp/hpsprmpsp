var sc = document.createElement('script');
sc.src = "script.js";
sc.type = "text/javascript";
document.getElementsByTagName('body')[0].appendChild(sc);

var data = {
    pageMeta: {
        title: 'Soumya Padhee\'s resume',
        icon: false,
        jsLibrary: ["https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"],
        cssLibrary: ["https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css", ]
    },

    pageHeader: {
        title: "Soumya Padhee's resume",
        background: "",
        onclick: "window.location.reload()"
    },
    bodyMenu: [

        {
            label: 'About',
            icon: 'glyphicon glyphicon-home',
            src: '#timeline',
            name: 'home_button'

        },
        {
            label: 'Timeline',
            icon: 'glyphicon glyphicon-road',
            src: '#timeline',
            name: 'professional'
        },
        {
            label: 'Experiance',
            icon: 'glyphicon glyphicon-list-alt',
            src: '#experiance',
            name: 'experiance'
        }
    ],
    bodyContent: [{
            type: 'about',
            title: 'About',
            id: 'about',
            content: "A dynamic professional with 5+ years of IT experience in <b>UI Development</b> looking for assignments in the domain of Software Development to deliver solutions for complex technical requirements. "
            
        },
        {
            type: "summary",
            title: "Summary",
            id: 'summary',
            content: [
                {
                    label: "Experiance Summary",
                    cont: [
                        "5+ years of total IT Experience, in <b>UI development</b>",
                        "Worked extensively in designing SPAs using HTML5/CSS3/JavaScript",
                        "Experienced in multiple JavaScript library, AngularJS 1.x, Bootstrap 3, Handlebars, JQuery",
                        "Experienced in designing small web application",
                        "Experienced in Node.js",
                        "Experienced in GIT",
                        "Average experience in Python, PHP",
                        "Average experience in Excel Macro using VBA"
                    ]
                },
                {
                    label: "Roles & Responsibilities",
                    cont: [
                        "Currently working as Member of technical staff",
                        "Accomplished major role in design and implementation of interface for business logic and flow",
                        "Involved in Designed, development and deployment phase of the project",
                        "Involved in design discussion and documentation of the framework",
                        "Involved in Code review",
                        "Worked as an Individual Contributor for the assigned task"
                    ]
                }
            ]


        },
        {
            type: 'timeline',
            title: 'Timeline',
            id: 'timeline',
            content: [{
                    time: { "date": "12", "month": "07", "year": "1991" },
                    timelineEvent: 'Day I was born',
                    icon: false
                },
                {
                    time: { "year": "2006" },
                    timelineEvent: 'Graduated from STD-X in Jawahar Navodaya Vidyalay, Belpada',
                    icon: false
                },
                {
                    time: { "year": "2008" },
                    timelineEvent: 'Graduated from STD-XII in DAV Model Sr Secondary School, Jeypore',
                    icon: false
                },
                {
                    time: { "year": "2012" },
                    timelineEvent: 'Garduated from Bachelor in Veer Surendra Sai University of technology, Burla ',
                    icon: false
                },
                {
                    time: { "date": "12", "month": "9", "year": "2012" },
                    timelineEvent: 'Joined Infosys',
                    icon: false
                },
                
                {
                    time: { "date": "20", "month": "11", "year": "2017" },
                    timelineEvent: 'Joined Riverbed',
                    icon: false
                }
                
            ]
        },
        
        {
            type: 'experiance',
            title: "Experiance",
            id: "experiance",
            content: [
                {
                    company : 'Infosys Limited',
                    startTime : { "month":"Sep","year": "2012" },
                    endTime : { "month":"Nov","year": "2017" },
                    projects : [
                        {
                            title : 'IPE',
                            type : 'Maintenance',
                            env : 'HTML5, CSS3. JavaScript, JQuery, Bootstrap, AngularJS 1.6, Unix, Oracle DB,Informatica PowerCentre 9.1',
                            desc : "I was responsible for keeping the environments up for floor management, keeping codes up-to-date. I was responsible for designing UI for automation.",  
                        },
                        {
                            company : 'Infosys Limited',
                            title : 'VOY',
                            startTime : { "month":"Sep","year": "2012" },
                            endTime : { "month":"Nov","year": "2017" },
                            type : 'Internal',
                            env : 'HTML5, CSS3. JavaScript, JQuery, Bootstrap, AngularJS 1.6',
                            desc : "VOY was responsible for organizing different events inside Infosys. I was involved in designing pages for invitations, registration, score maintenance etc. I designed a website using PHP for real-e-state ads.",
                        }
                    ]
                },
                
                {
                    company : 'Riverbed Limited',
                    startTime : { "month":"Nov","year": "2017" },
                    projects : [
                        {
                            title : 'SCM',
                            type : 'Product Developement',
                            env : 'HTML5, CSS3. JavaScript, JQuery, Bootstrap, Handlebars, AngularJS 1.6,GIT, Docker',
                            desc : "SCM is a product developed using Handlebars, and Bootstrap, Perl to replace the CLI controller for different hardware.",
                        }
                    ]
                }
            ],

        },
        
        {
            type: "education",
            title: "Education",
            id: 'education',
            content: [
                {
                    degree : 'Bachelor of Engineering',
                    inst : 'Veer Surendra Sai University of Technology, Burla',
                    start: { "year": "2008" },
                    end : {"year":"2012"},
                    major: 'Electronics and Telecommunication',
                    mark : '7.03 CGPA'
                },
                {
                    degree : 'Higher Secondary',
                    inst : 'Central Board of Secondary Education',
                    mark : '78.2%'
                },
                {
                    degree : 'Secondary',
                    inst : 'Central Board of Secondary Education',
                    mark : '81.4%'
                }
            ]


        },
        {
            type: "personalInformation",
            title: "Personal Information",
            id: 'personalInformation',
            content: [
                 {
                    label: 'Permanent Address',
                    content : 'C/O : Radhamohan Padhee <br /> AT/PO : Khairmal <br />Block: Belpada <br /> Dist: Balangir<br /> Odisha, PIN-767026',
                    
                },
                {
                    label: 'Present Address',
                    content : 'B305, SSVR TRIDAX <br />Balagere Rd, Varthur<br > Bengaluru, PIN-560087',
                    
                },
                {
                    label : 'Email',
                    content : 'soumya.sarthak.padhee@gmail.com',
                    type : 'email'
                },
                {
                    label : 'Phone number',
                    content : '+91-9652147435',
                    type : 'phone' 
                    
                },
                {
                    label: 'Passport',
                    content : "<b>Passport number:</b> J7316186<br /><b>Issued on:</b> 04th June 2012<br /><b>Valid till:</b> 03rd June 2022"
                },
                {
                    label : 'DOB',
                    content : { "date": "6", "month": "10", "year": "2017" },
                    type : 'date'
                },
                {
                    label: 'Marital Status',
                    content: 'Single'
                }

            ]
        }
    ],
    pageFooter: []

};
